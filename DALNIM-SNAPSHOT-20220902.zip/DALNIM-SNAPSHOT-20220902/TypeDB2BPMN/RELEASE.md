# Release notes

## 0.0.2

- Added support for tags which are sensitive to position/ordering, such as the *waypoint* tag. *BPMNattrib_sort* attribute will store their positions.
 
## 0.0.1

- Initial release