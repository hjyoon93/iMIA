# Release notes

## 0.0.4

- Added support for tags which are sensitive to position/ordering, such as the *waypoint* tag. *BPMNattrib_sort* attribute will store their positions.

## 0.0.3

- Added support for BPMN data references.

## 0.0.2

- Substituted Resource with Asset in conceptual model.

- Updated some typeql rules to reflect the above change.

- Bugfixes and instrumentation.
 
## 0.0.1

- Initial release